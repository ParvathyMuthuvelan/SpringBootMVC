package com.service;

import org.springframework.stereotype.Service;

import com.bean.Productt;

@Service
public class DiscountServiceImpl implements DiscountService {

	public double calculatePrice(Productt product) {
		double discountPrice = 0;
		String productType = product.getProductType();
		
		double price=product.getProductPrice();
		System.out.println("type="+productType+" "+price);
		if (productType.equals("Electronic"))
			// Electronic 25 Apparels 10 Toys 50
		{
			discountPrice = price -	(price * 0.25);
			System.out.println("electronic="+discountPrice);
		}
		
		else if (productType.equals("Apparels"))
			discountPrice = product.getProductPrice() - 
			(product.getProductPrice() *  0.10);
		else
			discountPrice = product.getProductPrice() - 
			(product.getProductPrice() *  0.50);
		
		//System.out.println(product.getProductPrice() +" "+discountPrice);
	    return discountPrice;
	}
}
