package com.service;

import com.bean.Productt;

public interface DiscountService {
public double calculatePrice(Productt  product);
}
