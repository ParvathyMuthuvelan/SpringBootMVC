package com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bean.Employee;
import com.dao.EmployeeDao;
@Service
public class EmployeeServiceImpl implements EmployeeService{
@Autowired
	EmployeeDao empDao;

	public void setEmpDao(EmployeeDao empDao) {
	this.empDao = empDao;
}

	@Override
	public List<Employee> fetchEmployees() {
		List<Employee> empList=empDao.fetchEmployees();
		return empList;
	}

	@Override
	public void addEmployee(Employee emp) {
		empDao.addEmployee(emp);
		
	}

	@Override
	public Employee getEmployee(int empId) {
		Employee emp=empDao.getEmployee(empId);
		return emp;
	}

	@Override
	public void updateEmployee(Employee emp) {
		empDao.updateEmployee(emp);
		
	}

	@Override
	public void deleteEmployee(int empId) {
		empDao.deleteEmployee(empId);
		
	}

}
