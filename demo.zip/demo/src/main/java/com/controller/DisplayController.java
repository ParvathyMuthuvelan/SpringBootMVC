package com.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.SessionAttribute;

import com.bean.LoginBean;

@Controller

public class DisplayController {

   
   @GetMapping("/info")
   public String userInfo(@SessionAttribute("login") LoginBean log) {

      System.out.println("Username: " + log.getUserName());
    
      return "user";
   }
}

