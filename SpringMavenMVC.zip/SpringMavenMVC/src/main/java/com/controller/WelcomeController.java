package com.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class WelcomeController {
	//http://localhost:8080/SpringMavenMVC/welcome?name=
	@RequestMapping(value="/welcome",method=RequestMethod.GET)
	public String showMessage(ModelMap map)
	{
		
		map.addAttribute("msg", "Request processed !.. Welcome ");
		return "welcome";
	}
	@RequestMapping(value="/add",method=RequestMethod.GET)
	public String addEmployee()
	{
		
		return "success";
	}
	
}
